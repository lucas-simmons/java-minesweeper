package edu.unca.csci202;
public class Minesweeper {
	/**
	 * Main method to run the game.
	 * @param args
	 */
	public static void main(String[] args) {

		Gameboard mine = new Gameboard();
		mine.run();
	}
}
